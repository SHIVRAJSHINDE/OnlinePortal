package com.niit.dao;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.niit.model.Category;
import com.niit.model.Product;
import com.niit.model.User;

@Repository
public class ProductDaoImpl implements ProductDao {
@Autowired
private SessionFactory sessionFactory;
	public List<Product> getAllProducts() {
		Session session=sessionFactory.getCurrentSession();
		//HQL - Hibernate query Language
		Query query=session.createQuery("from Product");//Select * from Product
		return query.list(); //List of Product objects
	}
	
	public Product getProduct(int id) {
		Session session=sessionFactory.getCurrentSession();
		Product product=(Product)session.get(Product.class, id); //select * from product where id=1
		return product;
	}
	public void deleteProduct(int id) {
		Session session=sessionFactory.getCurrentSession();
		//select * from product where id=?
		Product product=(Product)session.get(Product.class, id);
		//delete from product where id=?
		session.delete(product);
	}

	public List<Category> getCategories() {
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Category");
		return query.list();//List of Category objects
	}
	public void saveOrUpdateProduct(Product product) {
		Session session=sessionFactory.getCurrentSession();
		System.out.println("BEFORE INSERT/UPDATE " + product.getId());
		//if id==0, insert query
		//if id exits in the table, update query
		session.saveOrUpdate(product);//INsert into product values (?,.....)
		System.out.println("AFTER INSERT/UPDATE " + product.getId());
		
	}
	
	@Override
	public Category getCategory(int catid) {
		Session session=sessionFactory.getCurrentSession();
		Category category=(Category)session.get(Category.class, catid); //select * from product where id=1
		return category;
	}
	@Override
	public void deleteCategory(int id) {
		Session session=sessionFactory.getCurrentSession();
		//select * from product where id=?
		Category category=(Category)session.get(Category.class, id);
		//delete from product where id=?
		session.delete(category);		
	}
	@Override
	public void saveOrUpdateCategory(Category categories) {
		Session session=sessionFactory.getCurrentSession();
		System.out.println("before insert" + categories.getId());
		session.saveOrUpdate(categories);//insert into product values(?,....);
		System.out.println("after insert" + categories.getId());
	
		
	}
	
	
	

	//public User getUser(String username) {
		//Session session=sessionFactory.getCurrentSession();
		//User user=(User)session.get(User.class,username);
		//return user;
	//}
	
}

